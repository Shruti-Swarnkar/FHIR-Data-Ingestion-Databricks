# Databricks notebook source
resources = [
    "patient",
    "encounter",
    "observation",
    "condition"
]

for resource in resources:

    silver_table = f"workspace.default.{resource}_silver"
    gold_view = f"workspace.default.gold_{resource}"

    spark.sql(f"""
        CREATE OR REPLACE VIEW {gold_view} AS
        SELECT *
        FROM {silver_table}
        WHERE is_current = true
    """)

    print(f"Created Gold View: {gold_view}")

# COMMAND ----------

gold_views = [
    "gold_patient",
    "gold_encounter",
    "gold_observation",
    "gold_condition"
]

for view_name in gold_views:

    df = spark.table(f"workspace.default.{view_name}")

    print(
        view_name,
        "Records:",
        df.count()
    )

# COMMAND ----------

spark.sql("""
CREATE OR REPLACE VIEW workspace.default.gold_patient_encounter AS

SELECT
    e.id AS encounter_id,
    p.id AS patient_id,
    p.gender,
    p.birthDate,
    e.status AS encounter_status,
    e.class AS encounter_class
FROM workspace.default.gold_encounter e
LEFT JOIN workspace.default.gold_patient p
    ON regexp_replace(e.subject.reference, 'Patient/', '') = p.id
""")

print("Created Gold analytical view: gold_patient_encounter")

# COMMAND ----------

display(
    spark.table(
        "workspace.default.gold_patient_encounter"
    ).limit(20)
)

# COMMAND ----------

checks = {
    "patient_bronze": "workspace.default.patient_bronze",
    "encounter_bronze": "workspace.default.encounter_bronze",
    "observation_bronze": "workspace.default.observation_bronze",
    "condition_bronze": "workspace.default.condition_bronze",

    "patient_silver": "workspace.default.patient_silver",
    "encounter_silver": "workspace.default.encounter_silver",
    "observation_silver": "workspace.default.observation_silver",
    "condition_silver": "workspace.default.condition_silver",

    "gold_patient": "workspace.default.gold_patient",
    "gold_encounter": "workspace.default.gold_encounter",
    "gold_observation": "workspace.default.gold_observation",
    "gold_condition": "workspace.default.gold_condition"
}

for name, table_name in checks.items():
    count = spark.table(table_name).count()
    print(f"{name}: {count} records")

# COMMAND ----------

display(
    spark.table("workspace.default.patient_bronze")
    .select(
        "id",
        "extraction_timestamp",
        "api_url_or_params",
        "load_date",
        "source_resource"
    )
    .limit(10)
)

# COMMAND ----------

display(
    spark.table(
        "workspace.default.gold_patient_encounter"
    ).limit(20)
)