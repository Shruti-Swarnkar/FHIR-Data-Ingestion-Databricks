# Databricks notebook source
resource_name = "Patient"

bronze_table = f"workspace.default.{resource_name.lower()}_bronze"
silver_table = f"workspace.default.{resource_name.lower()}_silver"

print("Bronze:", bronze_table)
print("Silver:", silver_table)

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import Window

bronze_df = spark.table(bronze_table)

window_spec = Window.partitionBy("id").orderBy(
    F.col("extraction_timestamp").desc()
)

latest_df = (
    bronze_df
    .withColumn("rn", F.row_number().over(window_spec))
    .filter(F.col("rn") == 1)
    .drop("rn")
)

print("Incoming Bronze Records:", bronze_df.count())
print("After Deduplication:", latest_df.count())

# COMMAND ----------

technical_columns = [
    "extraction_timestamp",
    "api_url_or_params",
    "load_date",
    "source_resource"
]

business_columns = [
    c for c in latest_df.columns
    if c not in technical_columns
]

hash_df = latest_df.withColumn(
    "record_hash",
    F.sha2(
        F.concat_ws(
            "||",
            *[
                F.coalesce(
                    F.col(c).cast("string"),
                    F.lit("")
                )
                for c in business_columns
            ]
        ),
        256
    )
)

print("Business columns used:", len(business_columns))

# COMMAND ----------

from delta.tables import DeltaTable

if not spark.catalog.tableExists(silver_table):

    silver_df = (
        hash_df
        .withColumn("effective_from", F.current_timestamp())
        .withColumn("effective_to", F.lit(None).cast("timestamp"))
        .withColumn("is_current", F.lit(True))
    )

    (
        silver_df.write
        .format("delta")
        .mode("overwrite")
        .saveAsTable(silver_table)
    )

    print("Initial Silver SCD2 table created")

else:
    print("Silver table already exists")

# COMMAND ----------

silver_check = spark.table(silver_table)

print("Silver Records:", silver_check.count())

display(
    silver_check.select(
        "id",
        "record_hash",
        "effective_from",
        "effective_to",
        "is_current"
    ).limit(10)
)

# COMMAND ----------

from delta.tables import DeltaTable
from pyspark.sql import functions as F

delta_silver = DeltaTable.forName(spark, silver_table)

(
    delta_silver.alias("target")
    .merge(
        hash_df.alias("source"),
    )
    .whenMatchedUpdate(
        condition="""
        target.record_hash <> source.record_hash
        """,
        set={
            "is_current": "false",
            "effective_to": "current_timestamp()"
        }
    )
    .execute()
)

print("Changed existing records expired successfully")

# COMMAND ----------

current_silver = (
    spark.table(silver_table)
    .filter(F.col("is_current") == True)
    .select(
        "id",
        F.col("record_hash").alias("current_record_hash")
    )
)

records_to_insert = (
    hash_df.alias("source")
    .join(
        current_silver.alias("target"),
        on="id",
        how="left"
    )
    .filter(
        F.col("current_record_hash").isNull()
        |
        (
            F.col("record_hash")
            != F.col("current_record_hash")
        )
    )
    .drop("current_record_hash")
)

print(
    "New / Changed Records:",
    records_to_insert.count()
)

# COMMAND ----------

new_versions = (
    records_to_insert
    .withColumn(
        "effective_from",
        F.current_timestamp()
    )
    .withColumn(
        "effective_to",
        F.lit(None).cast("timestamp")
    )
    .withColumn(
        "is_current",
        F.lit(True)
    )
)

insert_count = new_versions.count()

if insert_count > 0:

    (
        new_versions.write
        .format("delta")
        .mode("append")
        .option("mergeSchema", "true")
        .saveAsTable(silver_table)
    )

    print(
        f"{insert_count} new SCD2 versions inserted"
    )

else:

    print("No new or changed records to insert")

# COMMAND ----------

result_df = spark.table(silver_table)

print("Total Silver Records:", result_df.count())

print(
    "Current Records:",
    result_df.filter(
        F.col("is_current") == True
    ).count()
)

print(
    "Historical Records:",
    result_df.filter(
        F.col("is_current") == False
    ).count()
)

display(
    result_df.select(
        "id",
        "effective_from",
        "effective_to",
        "is_current",
        "record_hash"
    ).orderBy("id")
)

# COMMAND ----------

from pyspark.sql import functions as F

test_patient = (
    spark.table("workspace.default.patient_bronze")
    .orderBy(F.col("extraction_timestamp").desc())
    .limit(1)
)

display(test_patient.select("id", "gender", "extraction_timestamp"))

# COMMAND ----------

from pyspark.sql import functions as F

demo_change = (
    test_patient
    .withColumn(
        "gender",
        F.when(F.col("gender") == "male", F.lit("female"))
         .when(F.col("gender") == "female", F.lit("male"))
         .otherwise(F.lit("other"))
    )
    .withColumn(
        "extraction_timestamp",
        F.current_timestamp()
    )
    .withColumn(
        "api_url_or_params",
        F.lit("SCD2_DEMO_CHANGE")
    )
    .withColumn(
        "load_date",
        F.date_format(F.current_timestamp(), "yyyy-MM-dd")
    )
)

print("Demo changed record:")
display(
    demo_change.select(
        "id",
        "gender",
        "extraction_timestamp"
    )
)

# COMMAND ----------

(
    demo_change.write
    .format("delta")
    .mode("append")
    .option("mergeSchema", "true")
    .saveAsTable("workspace.default.patient_bronze")
)

print("Demo changed Patient record appended to Bronze")

# COMMAND ----------

from pyspark.sql import functions as F

# Get only IDs having more than one historical version
scd2_history = (
    spark.table("workspace.default.patient_silver")
    .groupBy("id")
    .count()
    .filter(F.col("count") > 1)
)

display(scd2_history)

# COMMAND ----------

changed_ids = scd2_history.select("id")

history_detail = (
    spark.table("workspace.default.patient_silver")
    .join(changed_ids, on="id", how="inner")
    .select(
        "id",
        "gender",
        "effective_from",
        "effective_to",
        "is_current"
    )
    .orderBy("id", "effective_from")
)

display(history_detail)

# COMMAND ----------

from pyspark.sql import functions as F

changed_ids = (
    spark.table("workspace.default.patient_silver")
    .groupBy("id")
    .count()
    .filter(F.col("count") > 1)
    .select("id")
)

display(
    spark.table("workspace.default.patient_silver")
    .join(changed_ids, "id")
    .select(
        "id",
        "gender",
        "effective_from",
        "effective_to",
        "is_current"
    )
    .orderBy("id", "effective_from")
)

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SELECT
# MAGIC     resource_name,
# MAGIC     load_timestamp,
# MAGIC     load_date,
# MAGIC     status,
# MAGIC     api_url
# MAGIC FROM workspace.default.fhir_load_audit
# MAGIC ORDER BY load_timestamp DESC;

# COMMAND ----------

from pyspark.sql import functions as F

changed_ids = (
    spark.table("workspace.default.patient_silver")
    .groupBy("id")
    .count()
    .filter(F.col("count") > 1)
    .select("id")
)

display(
    spark.table("workspace.default.patient_silver")
    .join(changed_ids, "id")
    .select(
        "id",
        "gender",
        "effective_from",
        "effective_to",
        "is_current"
    )
    .orderBy("id", "effective_from")
)