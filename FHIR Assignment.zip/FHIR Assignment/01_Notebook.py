# Databricks notebook source
BASE_URL = "https://hapi.fhir.org/baseR4"

CATALOG_NAME = "workspace"
SCHEMA_NAME = "default"

RAW_VOLUME = "fhir_raw"

RAW_BASE_PATH = f"/Volumes/{CATALOG_NAME}/{SCHEMA_NAME}/{RAW_VOLUME}"

RESOURCES = [
    "Patient",
    "Encounter",
    "Observation",
    "Condition"
]

print("FHIR Configuration Loaded Successfully")
print("Base URL:", BASE_URL)
print("Raw Path:", RAW_BASE_PATH)
print("Resources:", RESOURCES)

# COMMAND ----------

import requests
import json
from datetime import datetime

def get_next_page_url(bundle_json):
    for link in bundle_json.get("link", []):
        if link.get("relation") == "next":
            return link.get("url")

    return None

# COMMAND ----------

def fetch_fhir_page(url, params=None):
    response = requests.get(
        url,
        params=params,
        timeout=60
    )

    response.raise_for_status()

    return response.json(), response.url

# COMMAND ----------

def save_raw_json(
    data,
    resource_name,
    load_date,
    page_number
):

    folder_path = (
        f"{RAW_BASE_PATH}/"
        f"{resource_name}/"
        f"{load_date}"
    )

    dbutils.fs.mkdirs(folder_path)

    file_path = (
        f"{folder_path}/"
        f"page_{page_number:03d}.json"
    )

    dbutils.fs.put(
        file_path,
        json.dumps(data),
        overwrite=True
    )

    return file_path

# COMMAND ----------

test_url = f"{BASE_URL}/Patient"

test_data, actual_url = fetch_fhir_page(
    test_url,
    {
        "_count": 5
    }
)

print("API Call Successful")
print("URL:", actual_url)
print("Resource Type:", test_data.get("resourceType"))
print("Number of Entries:", len(test_data.get("entry", [])))

# COMMAND ----------

load_date = datetime.now().strftime("%Y-%m-%d")

saved_path = save_raw_json(
    test_data,
    "Patient",
    load_date,
    1
)

print("Raw JSON saved successfully")
print(saved_path)

# COMMAND ----------

spark.sql("""
CREATE TABLE IF NOT EXISTS workspace.default.fhir_load_audit
(
    resource_name STRING,
    load_timestamp TIMESTAMP,
    load_date DATE,
    status STRING,
    api_url STRING
)
USING DELTA
""")

print("Audit table ready")

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SELECT
# MAGIC     resource_name,
# MAGIC     load_date,
# MAGIC     load_timestamp,
# MAGIC     status,
# MAGIC     api_url
# MAGIC FROM workspace.default.fhir_load_audit
# MAGIC ORDER BY load_timestamp DESC;