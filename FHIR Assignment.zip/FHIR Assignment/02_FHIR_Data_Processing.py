# Databricks notebook source
# MAGIC %run ./01_Notebook

# COMMAND ----------

resource_name = "Patient"
print("Processing Resource:", resource_name)

# COMMAND ----------

api_url = f"{BASE_URL}/{resource_name}"

params = {
    "_count": 100
}

print("API URL:", api_url)

# COMMAND ----------

from datetime import datetime

load_date = datetime.now().strftime("%Y-%m-%d")

api_url = f"{BASE_URL}/{resource_name}"

params = {
    "_count": 100
}

print("Load Date:", load_date)
print("API URL:", api_url)
print("Parameters:", params)

# COMMAND ----------

all_resources = []

current_url = api_url
current_params = params

page_number = 1

while current_url:

    print(f"Fetching page {page_number}...")

    bundle, actual_url = fetch_fhir_page(
        current_url,
        current_params
    )

    # Save complete API response as-is in Raw layer
    saved_path = save_raw_json(
        bundle,
        resource_name,
        load_date,
        page_number
    )

    print("Saved:", saved_path)

    # Extract individual FHIR resources
    for entry in bundle.get("entry", []):
        resource = entry.get("resource")

        if resource:
            all_resources.append(resource)

    # Get next page
    current_url = get_next_page_url(bundle)

    # Next URL already contains parameters
    current_params = None

    page_number += 1

    # Safety limit for assignment/demo
    if page_number > 3:
        print("Demo pagination limit reached.")
        break


print("--------------------------------")
print("Raw ingestion completed")
print("Total pages:", page_number - 1)
print("Total FHIR records:", len(all_resources))

# COMMAND ----------

# Read the JSON files directly from Raw Layer
raw_folder_path = f"{RAW_BASE_PATH}/{resource_name}/{load_date}"

print("Reading Raw data from:", raw_folder_path)

bundle_df = (
    spark.read
    .option("multiLine", "true")
    .json(f"{raw_folder_path}/*.json")
)

# FHIR Bundle -> individual resources
from pyspark.sql.functions import explode

df = (
    bundle_df
    .select(explode("entry").alias("entry"))
    .select("entry.resource.*")
)

print("FHIR records converted to DataFrame successfully")
print("Record Count:", df.count())

display(df.limit(10))

# COMMAND ----------

from pyspark.sql.functions import current_timestamp, lit

df_bronze = (
    df
    .withColumn(
        "extraction_timestamp",
        current_timestamp()
    )
    .withColumn(
        "api_url_or_params",
        lit(f"{api_url}?_count=100")
    )
    .withColumn(
        "load_date",
        lit(load_date)
    )
    .withColumn(
        "source_resource",
        lit(resource_name)
    )
)

display(
    df_bronze.select(
        "id",
        "resourceType",
        "extraction_timestamp",
        "api_url_or_params",
        "load_date",
        "source_resource"
    ).limit(10)
)

# COMMAND ----------

bronze_table = (
    f"{CATALOG_NAME}.{SCHEMA_NAME}."
    f"{resource_name.lower()}_bronze"
)

print("Writing Bronze Table:", bronze_table)

(
    df_bronze.write
    .format("delta")
    .mode("append")
    .option("mergeSchema", "true")
    .saveAsTable(bronze_table)
)

print("Bronze Delta saved successfully")

# COMMAND ----------

check_df = spark.table(bronze_table)

print("Bronze Record Count:", check_df.count())

display(check_df.limit(10))

# COMMAND ----------

from pyspark.sql import functions as F

audit_df = spark.createDataFrame(
    [
        (
            resource_name,
            "SUCCESS",
            api_url
        )
    ],
    [
        "resource_name",
        "status",
        "api_url"
    ]
)

audit_df = (
    audit_df
    .withColumn("load_timestamp", F.current_timestamp())
    .withColumn("load_date", F.current_date())
    .select(
        "resource_name",
        "load_timestamp",
        "load_date",
        "status",
        "api_url"
    )
)

(
    audit_df.write
    .format("delta")
    .mode("append")
    .saveAsTable("workspace.default.fhir_load_audit")
)

print("Load audit logged successfully")

# COMMAND ----------

display(
    spark.table("workspace.default.patient_bronze")
    .select(
        "id",
        "extraction_timestamp",
        "api_url_or_params",
        "load_date",
        "source_resource"
    )
    .limit(10)
)