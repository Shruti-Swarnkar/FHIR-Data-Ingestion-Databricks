# Databricks notebook source
try:
    resource_name
except NameError:
    resource_name = "Condition"

print("Processing Resource:", resource_name)

# COMMAND ----------

# MAGIC %run ./02_FHIR_Data_Processing